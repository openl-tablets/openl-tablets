package org.openl.example;

public interface ServiceClass {
    String invoke();
}
