package org.openl.example;

public class JavaBean {
    private int intField;

    public int getIntField() {
        return this.intField;
    }

    public void setIntField(int intField) {
        this.intField = intField;
    }
}
