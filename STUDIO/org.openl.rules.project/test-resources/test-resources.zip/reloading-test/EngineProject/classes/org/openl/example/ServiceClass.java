package org.openl.example;

public interface ServiceClass {
    int getInt(JavaBean var1);

    String invoke();
}
