---
# SPDX-License-Identifier: Apache-2.0
table: SmartRules String farewell(Integer hour)
license: Apache-2.0
properties:
  description: Says goodbye by the hour
merges:
  - A1:C1
---

Three problems of the front matter: a key it does not know, a description written as a property, and a merged
range wider than the table. The table is read without them.

| Hour  | Farewell       |
|-------|----------------|
| 0-11  | Have a nice day |
| 12-23 | Good night     |
