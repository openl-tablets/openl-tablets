---
table: SmartRules String greeting(Integer hour)
---

A file that breaks no rule of the format: the Files tab marks nothing in it.

| Hour  | Greeting       |
|-------|----------------|
| 0-11  | Good Morning   |
| 12-23 | Good Afternoon |
