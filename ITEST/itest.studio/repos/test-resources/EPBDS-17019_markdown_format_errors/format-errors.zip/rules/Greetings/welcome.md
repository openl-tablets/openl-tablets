---
table: SmartRules String welcome(Integer hour)

The front matter is never closed with a line of three dashes, so the file holds no table.

| Hour  | Welcome  |
|-------|----------|
| 0-23  | Welcome! |
