---
table: SmartRules String salute(Integer hour)
---

The second row has a third cell that GFM would drop without a word.

| Hour  | Salute         |
|-------|----------------|
| 0-11  | Good Morning   | extra |
| 12-23 | Good Afternoon |
