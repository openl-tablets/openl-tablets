---
table: Datatype Policy
---

An auto policy: where it is written, its drivers and its vehicle.

| Type     | Name      |
|----------|-----------|
| String   | state     |
| Driver[] | drivers   |
| Vehicle  | vehicle   |
| Double   | premium   |
| String   | agentCode |
