---
table: Datatype Driver
---

A driver of a policy.

| Type    | Name         |
|---------|--------------|
| String  | name         |
| Integer | age          |
| Integer | licenseYears |
| Integer | points       |
| String  | email        |
