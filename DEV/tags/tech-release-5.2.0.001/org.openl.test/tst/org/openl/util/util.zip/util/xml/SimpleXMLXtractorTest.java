/*
 * Created on Jun 1, 2003
 *
 *  Copyright Intelligent ChoicePoint Inc. 2003
 */
 
package org.openl.util.xml;

import junit.framework.TestCase;

/**
 * @author snshor
 *
 */
public class SimpleXMLXtractorTest extends TestCase
{

  /**
   * Constructor for SimpleXMLXtractorTest.
   * @param arg0
   */
  public SimpleXMLXtractorTest(String arg0)
  {
    super(arg0);
  }
  
  public void testRegisterHandler()
  {
  	
  	
  }
  
  static class TestHandler extends SimpleXMLXtractor.Handler
  {
  	
  	
  }
  

}
